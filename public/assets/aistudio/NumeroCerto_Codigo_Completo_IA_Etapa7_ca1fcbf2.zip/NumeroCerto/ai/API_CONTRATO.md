# Contrato da API da NumeroCerto AI

## POST /api/ai/analyze
Entrada:
```json
{
  "module": "prize_vision | rules_safety | finance | transparency",
  "question": "texto de até 6000 caracteres",
  "image": {
    "mimeType": "image/jpeg | image/png | image/webp",
    "base64": "conteúdo base64 sem necessidade de prefixo data:"
  }
}
```
`image` é opcional. Tamanho máximo de imagem: 3 MB. Corpo HTTP máximo: 5 MB.

Resposta 200:
```json
{
  "requestId": "UUID",
  "module": "rules_safety",
  "answer": "texto gerado pelo modelo",
  "mode": "gemini",
  "warning": "Resposta de IA pode conter erros..."
}
```

Erros possíveis: `400 invalid_json|invalid_module|invalid_question|image_*`, `401 unauthorized`, `413 payload_too_large`, `502 model_provider_error|empty_model_response|model_unavailable`, `503 ai_not_configured`, `504 model_timeout`.

## Importante
O backend de referência não tem autenticação de usuário completa, rate limiting persistente, banco ou auditoria de produção. Não expor publicamente sem completar essas proteções.
