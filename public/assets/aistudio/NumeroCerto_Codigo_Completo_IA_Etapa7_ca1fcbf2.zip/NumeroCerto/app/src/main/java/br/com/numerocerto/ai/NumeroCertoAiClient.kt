package br.com.numerocerto.ai

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Cliente Android de referência para o backend NumeroCerto AI.
 *
 * Configure baseUrl para o endereço do SEU backend HTTPS.
 * Não coloque GEMINI_API_KEY neste app.
 * Este cliente é síncrono; chame-o em Dispatchers.IO, nunca na thread principal.
 */
enum class NumeroCertoAiModule(val apiValue: String) {
    PRIZE_VISION("prize_vision"),
    RULES_SAFETY("rules_safety"),
    FINANCE("finance"),
    TRANSPARENCY("transparency")
}

data class NumeroCertoAiResult(
    val module: String,
    val answer: String,
    val warning: String,
    val requestId: String?
)

class NumeroCertoAiClient(
    private val baseUrl: String,
    private val bearerTokenProvider: (() -> String?)? = null
) {
    @Throws(IOException::class)
    fun analyze(
        module: NumeroCertoAiModule,
        question: String,
        imageMimeType: String? = null,
        imageBase64: String? = null
    ): NumeroCertoAiResult {
        require(question.trim().length >= 2) { "Escreva uma pergunta com pelo menos 2 caracteres." }
        require(question.length <= 6000) { "A pergunta ultrapassa o limite de 6000 caracteres." }
        require((imageMimeType == null) == (imageBase64 == null)) {
            "Informe o tipo MIME e a imagem base64 juntos."
        }

        val body = JSONObject()
            .put("module", module.apiValue)
            .put("question", question.trim())

        if (imageMimeType != null && imageBase64 != null) {
            body.put("image", JSONObject()
                .put("mimeType", imageMimeType)
                .put("base64", imageBase64))
        }

        val connection = (URL(baseUrl.trimEnd('/') + "/api/ai/analyze").openConnection() as HttpURLConnection)
        connection.requestMethod = "POST"
        connection.connectTimeout = 10000
        connection.readTimeout = 35000
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        connection.setRequestProperty("Accept", "application/json")
        bearerTokenProvider?.invoke()?.takeIf { it.isNotBlank() }?.let {
            connection.setRequestProperty("Authorization", "Bearer $it")
        }

        try {
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val json = try { JSONObject(responseText) } catch (_: Exception) {
                throw IOException("Resposta inválida do servidor (HTTP $status).")
            }
            if (status !in 200..299) {
                val message = json.optString("message").ifBlank {
                    json.optString("error", "Erro do servidor")
                }
                throw IOException("$message (HTTP $status)")
            }
            val answer = json.optString("answer")
            if (answer.isBlank()) throw IOException("A IA retornou uma resposta vazia.")
            return NumeroCertoAiResult(
                module = json.optString("module", module.apiValue),
                answer = answer,
                warning = json.optString("warning"),
                requestId = json.optString("requestId").takeIf { it.isNotBlank() }
            )
        } finally {
            connection.disconnect()
        }
    }
}
