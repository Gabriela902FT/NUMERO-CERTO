# NumeroCerto AI — backend de referência

Servidor Node.js 20+ que encaminha texto e, opcionalmente, uma imagem para o Gemini. A chave do Gemini fica somente no servidor.

## Módulos aceitos
- `prize_vision`: análise visual/descritiva de prêmio.
- `rules_safety`: pendências e riscos de segurança.
- `finance`: cálculos estimados com pressupostos declarados.
- `transparency`: requisitos de auditoria e transparência.

## Executar localmente
1. Instale Node.js 20 ou superior.
2. Configure `GEMINI_API_KEY` no ambiente do servidor. Não coloque a chave no APK, no Git nem em prompt público.
3. Em desenvolvimento local, a autenticação pode ficar desativada (`NODE_ENV=development` e `APP_API_TOKEN` vazio). Não exponha esse modo à internet.
4. Inicie: `npm start`.
5. Verifique: `GET http://localhost:8080/health`.
6. Envie `POST http://localhost:8080/api/ai/analyze` com JSON como:
   `{"module":"rules_safety","question":"Revise esta descrição de sorteio e liste pendências."}`
7. Para imagem, envie `image: {"mimeType":"image/jpeg","base64":"..."};` somente JPEG, PNG ou WebP, até 3 MB.

## Autenticação e produção
Este é um backend inicial, não pronto para produção. Não há autenticação de usuários por Firebase, rate limit persistente, banco, política de moderação completa, proteção contra abuso, armazenamento de auditoria, monitoramento de custos ou implantação.
- Em produção, configure `NODE_ENV=production` e autenticação real com tokens curtos verificáveis no servidor.
- Não use `APP_API_TOKEN` estático embutido em APK como proteção de produção; ele pode ser extraído.
- Exija HTTPS, limites por conta/IP, controle de custos e logs sem dados pessoais.
- Não envie CPF, endereço, documentos, dados de pagamento ou informações pessoais desnecessárias ao modelo.
- Imagens são processadas na requisição e não são persistidas pelo código. O provedor pode ter políticas próprias; verifique termos e configurações antes de enviar dados reais.
- A IA não verifica autorização legal, identidade, pagamento nem autenticidade do prêmio. Use fluxos independentes e revisão humana.
- O resultado do sorteio deve ser criado por um mecanismo separado, auditável e conforme o regulamento, nunca pela IA.
