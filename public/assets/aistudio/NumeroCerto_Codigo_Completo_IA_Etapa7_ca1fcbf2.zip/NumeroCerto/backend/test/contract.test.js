import test from "node:test";
import assert from "node:assert/strict";

test("lista dos módulos permitidos permanece explícita", () => {
  const allowed = ["prize_vision", "rules_safety", "finance", "transparency"];
  assert.equal(new Set(allowed).size, 4);
  assert.ok(allowed.includes("prize_vision"));
  assert.ok(allowed.includes("rules_safety"));
  assert.ok(allowed.includes("finance"));
  assert.ok(allowed.includes("transparency"));
});

test("contrato limita imagens a formatos raster conhecidos", () => {
  const allowedMimeTypes = ["image/jpeg", "image/png", "image/webp"];
  assert.ok(allowedMimeTypes.includes("image/jpeg"));
  assert.ok(!allowedMimeTypes.includes("image/svg+xml"));
});
